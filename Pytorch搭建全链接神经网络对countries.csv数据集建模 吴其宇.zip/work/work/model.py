import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset, random_split
from io import BytesIO
import os
from typing import Tuple, List  # 新增：导入必要的类型提示


# 设置matplotlib中文字体（适配Windows系统）
def set_matplotlib_font():
    """设置matplotlib中文字体（优先使用Windows默认中文字体）"""
    try:
        # 优先使用Windows系统自带的"微软雅黑"（兼容性最好）
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
    except:
        #  fallback：若系统无微软雅黑，使用默认无衬线字体（避免中文乱码）
        plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False


# 初始化字体
set_matplotlib_font()


def load_data(file_path: str) -> Tuple[torch.Tensor, torch.Tensor, List[str], np.ndarray, np.ndarray]:
    """
    加载国家数据集并标准化
    返回：特征Tensor、归一化后的目标Tensor、特征名称、目标均值、目标标准差（用于后续反归一化）
    """
    data = pd.read_csv(file_path)

    # 提取特征和目标变量
    features = data.drop('gdp_per_capita', axis=1)
    target = data['gdp_per_capita'].values  # 转为numpy数组，方便计算均值/标准差

    # 1. 特征标准化（Z-score）
    feat_mean = features.mean()
    feat_std = features.std()
    features_norm = (features - feat_mean) / feat_std

    # 2. 目标变量归一化（Z-score，后续预测时需反归一化）
    target_mean = target.mean()
    target_std = target.std()
    target_norm = (target - target_mean) / target_std

    # 转换为Tensor
    x = torch.tensor(features_norm.values, dtype=torch.float32)
    y = torch.tensor(target_norm.reshape(-1, 1), dtype=torch.float32)

    return x, y, list(features.columns), target_mean, target_std


class CountryGDPNet(nn.Module):
    """预测国家人均GDP的全连接神经网络"""

    def __init__(self, input_size: int) -> None:
        super(CountryGDPNet, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_size, 64),
            nn.ReLU(),
            nn.BatchNorm1d(64),  # 批归一化：加速训练，提升稳定性
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Dropout(0.3),  # Dropout：防止过拟合
            nn.Linear(32, 16),
            nn.ReLU(),
            nn.Linear(16, 1)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.model(x)


def train_model(
        model: CountryGDPNet,
        optimizer: torch.optim.Optimizer,
        criterion: nn.MSELoss,
        train_loader: DataLoader,
        val_loader: DataLoader,
        epochs: int,
        device: torch.device
) -> Tuple[List[float], List[float]]:
    """训练模型并返回训练和验证损失"""
    train_losses: List[float] = []
    val_losses: List[float] = []

    for epoch in range(epochs):
        # 训练阶段
        train_loss = 0.0
        model.train()
        for x_batch, y_batch in train_loader:
            x_batch, y_batch = x_batch.to(device), y_batch.to(device)

            # 前向传播
            outputs = model(x_batch)
            loss = criterion(outputs, y_batch)

            # 反向传播和优化
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            train_loss += loss.item() * x_batch.size(0)  # 按样本数加权求和

        # 计算平均训练损失
        avg_train_loss = train_loss / len(train_loader.dataset)
        train_losses.append(avg_train_loss)

        # 验证阶段（无梯度计算）
        val_loss = 0.0
        model.eval()
        with torch.no_grad():
            for x_batch, y_batch in val_loader:
                x_batch, y_batch = x_batch.to(device), y_batch.to(device)
                outputs = model(x_batch)
                loss = criterion(outputs, y_batch)
                val_loss += loss.item() * x_batch.size(0)

        # 计算平均验证损失
        avg_val_loss = val_loss / len(val_loader.dataset)
        val_losses.append(avg_val_loss)

        # 每10个epoch打印一次信息（显示更简洁）
        if (epoch + 1) % 10 == 0:
            print(f'Epoch [{epoch + 1}/{epochs}] | 训练损失: {avg_train_loss:.4f} | 验证损失: {avg_val_loss:.4f}')

    return train_losses, val_losses


def plot_losses(train_losses: List[float], val_losses: List[float], save_path: str) -> None:
    """可视化训练和验证损失曲线"""
    plt.figure(figsize=(10, 6))
    plt.plot(range(1, len(train_losses) + 1), train_losses, label='训练损失', linewidth=2)
    plt.plot(range(1, len(val_losses) + 1), val_losses, label='验证损失', linewidth=2, linestyle='--')
    plt.xlabel('迭代次数（Epoch）', fontsize=11)
    plt.ylabel('MSE损失', fontsize=11)
    plt.title('国家GDP预测模型 - 训练与验证损失曲线', fontsize=12, pad=15)
    plt.legend(fontsize=10)
    plt.grid(True, linestyle=':', alpha=0.7)
    plt.tight_layout()  # 自动调整布局，避免标签被截断
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()


def plot_predictions(
        model: CountryGDPNet,
        data_loader: DataLoader,
        device: torch.device,
        target_mean: np.ndarray,
        target_std: np.ndarray,
        save_path: str
) -> None:
    """可视化预测值与实际值的对比（反归一化回原始GDP尺度）"""
    model.eval()
    all_preds_norm = []  # 模型输出的归一化预测值
    all_actual = []  # 原始实际值

    with torch.no_grad():
        for x_batch, y_batch_norm in data_loader:
            x_batch = x_batch.to(device)
            # 模型预测（归一化尺度）
            preds_norm = model(x_batch).cpu().numpy()
            # 反归一化：恢复为原始GDP尺度
            preds = preds_norm * target_std + target_mean
            # 实际值反归一化
            actual = y_batch_norm.cpu().numpy() * target_std + target_mean

            all_preds_norm.extend(preds.flatten())
            all_actual.extend(actual.flatten())

    # 计算R²分数（评估模型拟合优度，越接近1越好）
    ss_total = np.sum((np.array(all_actual) - np.mean(all_actual)) ** 2)
    ss_residual = np.sum((np.array(all_actual) - np.array(all_preds_norm)) ** 2)
    r2 = 1 - (ss_residual / ss_total)

    # 绘图
    plt.figure(figsize=(10, 6))
    plt.scatter(all_actual, all_preds_norm, alpha=0.6, s=50, label='样本点')
    # 绘制理想拟合线（y=x）
    plt.plot([min(all_actual), max(all_actual)],
             [min(all_actual), max(all_actual)],
             'r--', linewidth=2, label='理想拟合线')
    plt.xlabel('实际人均GDP（美元）', fontsize=11)
    plt.ylabel('预测人均GDP（美元）', fontsize=11)
    plt.title(f'国家GDP预测模型 - 预测值 vs 实际值（R² = {r2:.4f}）', fontsize=12, pad=15)
    plt.legend(fontsize=10)
    plt.grid(True, linestyle=':', alpha=0.7)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()


def plot_feature_importance(model: CountryGDPNet, feature_names: List[str], device: torch.device,
                            save_path: str) -> None:
    """分析并可视化特征重要性（基于梯度绝对值）"""
    model.eval()
    # 创建随机样本（用于计算特征对输出的梯度）
    x_sample = torch.randn(1, len(feature_names)).to(device)
    x_sample.requires_grad_()  # 开启梯度计算

    # 前向传播 + 反向传播（计算特征梯度）
    output = model(x_sample)
    output.backward()  # 对输入特征求导

    # 梯度绝对值归一化：作为特征重要性
    importance = torch.abs(x_sample.grad).cpu().detach().numpy().flatten()
    importance = importance / np.sum(importance)  # 归一化到0-1

    # 绘图（横向柱状图，按重要性排序）
    sorted_idx = np.argsort(importance)[::-1]  # 从大到小排序
    sorted_features = [feature_names[i] for i in sorted_idx]
    sorted_importance = importance[sorted_idx]

    plt.figure(figsize=(10, 6))
    plt.barh(sorted_features, sorted_importance, color='#1f77b4')
    plt.xlabel('相对重要性', fontsize=11)
    plt.title('国家GDP预测模型 - 特征重要性分析', fontsize=12, pad=15)
    plt.grid(axis='x', linestyle=':', alpha=0.7)
    # 在柱子上添加数值标签
    for i, v in enumerate(sorted_importance):
        plt.text(v + 0.01, i, f'{v:.3f}', va='center', fontsize=9)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()


def main() -> None:
    # 1. 初始化环境
    os.makedirs('results', exist_ok=True)  # 创建结果保存目录
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")

    # 2. 加载数据（含目标变量归一化）
    print("加载数据...")
    x, y, feature_names, target_mean, target_std = load_data("countries.csv")
    input_size = x.shape[1]
    print(f"特征数量: {input_size}, 样本数量: {x.shape[0]}")
    print(f"特征名称: {feature_names}")
    print(f"人均GDP均值: {target_mean:.2f} 美元, 标准差: {target_std:.2f} 美元")

    # 3. 划分训练集（80%）和验证集（20%）
    dataset = TensorDataset(x, y)
    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

    # 4. 创建数据加载器（批处理）
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)

    # 5. 初始化模型、损失函数、优化器
    model = CountryGDPNet(input_size).to(device)
    criterion = nn.MSELoss()  # 回归任务用MSE损失
    # Adam优化器（添加权重衰减防止过拟合）
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=1e-5)

    # 6. 训练模型
    print("\n开始训练模型...")
    epochs = 100
    train_losses, val_losses = train_model(model, optimizer, criterion, train_loader, val_loader, epochs, device)

    # 7. 生成可视化结果
    print("\n生成可视化结果...")
    plot_losses(train_losses, val_losses, 'results/loss_curves.png')
    plot_predictions(model, val_loader, device, target_mean, target_std, 'results/predictions.png')
    plot_feature_importance(model, feature_names, device, 'results/feature_importance.png')

    # 8. 保存模型和关键参数（方便后续加载使用）
    torch.save({
        'model_state_dict': model.state_dict(),
        'input_size': input_size,
        'target_mean': target_mean,
        'target_std': target_std,
        'feature_names': feature_names
    }, 'results/country_gdp_model.pth')

    print("模型已保存至: results/country_gdp_model.pth")
    print("所有结果（图表+模型）已保存到 'results' 目录")


if __name__ == '__main__':
    main()
