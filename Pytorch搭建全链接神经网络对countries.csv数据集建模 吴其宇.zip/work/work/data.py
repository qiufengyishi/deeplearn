import numpy as np
import pandas as pd
from io import StringIO
import os


def create_countries_data(num_countries: int = 100, output_path: str = "countries.csv") -> None:
    """生成国家数据集并保存为CSV文件"""
    np.random.seed(42)  # 设置随机种子，确保结果可复现

    # 生成特征数据
    data = {
        # 人口（百万）
        'population': np.random.lognormal(mean=3, sigma=0.8, size=num_countries),
        # 平均寿命（年）
        'life_expectancy': np.random.normal(loc=70, scale=8, size=num_countries),
        # 教育支出占GDP比例（%）
        'education_spending': np.random.uniform(low=2, high=8, size=num_countries),
        # 城市化率（%）
        'urbanization': np.random.uniform(low=30, high=95, size=num_countries),
        # 失业率（%）
        'unemployment': np.random.uniform(low=2, high=25, size=num_countries),
        # 自然资源丰富度（0-10）
        'natural_resources': np.random.uniform(low=0, high=10, size=num_countries)
    }

    # 创建DataFrame
    df = pd.DataFrame(data)

    # 生成人均GDP（目标变量），基于特征的非线性组合
    df['gdp_per_capita'] = (
            5000 * np.log(df['population'] + 1) +
            800 * (df['life_expectancy'] - 60) +
            1200 * df['education_spending'] +
            300 * np.log(df['urbanization']) +
            -500 * df['unemployment'] +
            600 * df['natural_resources'] +
            np.random.normal(loc=0, scale=3000, size=num_countries)  # 添加噪声
    )

    # 确保GDP为正值
    df['gdp_per_capita'] = df['gdp_per_capita'].clip(lower=1000)

    # 创建输出目录（如果需要）
    if '/' in output_path or '\\' in output_path:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # 保存为CSV文件
    df.to_csv(output_path, index=False)
    print(f"数据集已生成并保存至: {output_path}")
    print(f"数据集包含 {num_countries} 个国家样本和 {len(df.columns)} 个特征")


if __name__ == "__main__":
    # 生成包含200个国家数据的数据集
    create_countries_data(num_countries=200, output_path="countries.csv")