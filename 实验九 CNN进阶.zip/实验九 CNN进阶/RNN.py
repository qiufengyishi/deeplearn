import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
import matplotlib.pyplot as plt
import numpy as np
from tqdm import tqdm
import time


# ===================== 1. 配置参数与数据预处理 =====================
def get_data_loaders():
    batch_size = 128
    transform = transforms.Compose([
        transforms.Resize((32, 32)),
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,))
    ])

    train_dataset = datasets.MNIST(root='./data', train=True, download=True, transform=transform)
    test_dataset = datasets.MNIST(root='./data', train=False, download=True, transform=transform)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, num_workers=0)

    return train_loader, test_loader


# ===================== 2. 修复后的GoogleNet模型（通道数匹配） =====================
class Inception(nn.Module):
    def __init__(self, in_channels, ch1x1, ch3x3red, ch3x3, ch5x5red, ch5x5, pool_proj):
        super(Inception, self).__init__()
        # 1x1卷积分支
        self.branch1 = nn.Sequential(
            nn.Conv2d(in_channels, ch1x1, kernel_size=1),
            nn.BatchNorm2d(ch1x1),
            nn.ReLU(inplace=True)
        )
        # 3x3卷积分支
        self.branch2 = nn.Sequential(
            nn.Conv2d(in_channels, ch3x3red, kernel_size=1),
            nn.BatchNorm2d(ch3x3red),
            nn.ReLU(inplace=True),
            nn.Conv2d(ch3x3red, ch3x3, kernel_size=3, padding=1),
            nn.BatchNorm2d(ch3x3),
            nn.ReLU(inplace=True)
        )
        # 5x5卷积分支
        self.branch3 = nn.Sequential(
            nn.Conv2d(in_channels, ch5x5red, kernel_size=1),
            nn.BatchNorm2d(ch5x5red),
            nn.ReLU(inplace=True),
            nn.Conv2d(ch5x5red, ch5x5, kernel_size=5, padding=2),
            nn.BatchNorm2d(ch5x5),
            nn.ReLU(inplace=True)
        )
        # 池化分支
        self.branch4 = nn.Sequential(
            nn.MaxPool2d(kernel_size=3, stride=1, padding=1),
            nn.Conv2d(in_channels, pool_proj, kernel_size=1),
            nn.BatchNorm2d(pool_proj),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        branch1 = self.branch1(x)
        branch2 = self.branch2(x)
        branch3 = self.branch3(x)
        branch4 = self.branch4(x)
        outputs = torch.cat([branch1, branch2, branch3, branch4], 1)
        return outputs


class GoogleNet(nn.Module):
    def __init__(self, num_classes=10):
        super(GoogleNet, self).__init__()
        # 初始卷积层：单通道输入→64通道
        self.pre_layers = nn.Sequential(
            nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1)  # 输出尺寸：8x8
        )

        # Inception模块（严格匹配通道数）
        self.inception3a = Inception(64, 16, 16, 24, 8, 8, 8)  # 输出：16+24+8+8=56
        self.inception3b = Inception(56, 24, 24, 32, 8, 12, 12)  # 输入56→输出24+32+12+12=80
        self.maxpool3 = nn.MaxPool2d(3, stride=2, padding=1)  # 输出尺寸：4x4

        self.inception4a = Inception(80, 24, 20, 32, 8, 12, 12)  # 输出24+32+12+12=80
        self.inception4b = Inception(80, 28, 24, 36, 10, 14, 14)  # 输出28+36+14+14=92
        self.inception4c = Inception(92, 32, 28, 40, 12, 16, 16)  # 输出32+40+16+16=104
        self.inception4d = Inception(104, 32, 32, 48, 12, 16, 16)  # 输出32+48+16+16=112
        self.inception4e = Inception(112, 40, 36, 56, 14, 20, 20)  # 输出40+56+20+20=136
        self.maxpool4 = nn.MaxPool2d(3, stride=2, padding=1)  # 输出尺寸：2x2

        self.inception5a = Inception(136, 40, 40, 64, 16, 24, 24)  # 输出40+64+24+24=152
        self.inception5b = Inception(152, 48, 44, 72, 18, 28, 28)  # 输出48+72+28+28=176

        # 分类头
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.dropout = nn.Dropout(0.4)
        self.fc = nn.Linear(176, num_classes)

    def forward(self, x):
        x = self.pre_layers(x)
        x = self.inception3a(x)
        x = self.inception3b(x)
        x = self.maxpool3(x)
        x = self.inception4a(x)
        x = self.inception4b(x)
        x = self.inception4c(x)
        x = self.inception4d(x)
        x = self.inception4e(x)
        x = self.maxpool4(x)
        x = self.inception5a(x)
        x = self.inception5b(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.dropout(x)
        x = self.fc(x)
        return x


# ===================== 3. ResNet模型（保持不变） =====================
class ResidualBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, downsample=None):
        super(ResidualBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.downsample = downsample

    def forward(self, x):
        residual = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        out = self.conv2(out)
        out = self.bn2(out)
        if self.downsample is not None:
            residual = self.downsample(x)
        out += residual
        out = self.relu(out)
        return out


class ResNet(nn.Module):
    def __init__(self, num_classes=10):
        super(ResNet, self).__init__()
        self.in_channels = 64
        self.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        self.layer1 = self._make_layer(64, 2, stride=1)
        self.layer2 = self._make_layer(128, 2, stride=2)
        self.layer3 = self._make_layer(256, 2, stride=2)
        self.layer4 = self._make_layer(512, 2, stride=2)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512, num_classes)

    def _make_layer(self, out_channels, num_blocks, stride):
        downsample = None
        if stride != 1 or self.in_channels != out_channels:
            downsample = nn.Sequential(
                nn.Conv2d(self.in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels)
            )
        layers = []
        layers.append(ResidualBlock(self.in_channels, out_channels, stride, downsample))
        self.in_channels = out_channels
        for _ in range(1, num_blocks):
            layers.append(ResidualBlock(self.in_channels, out_channels))
        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x


# ===================== 4. 训练与测试函数 =====================
def train_model(model, train_loader, criterion, optimizer, num_epochs, device):
    model.train()
    train_losses = []
    train_accs = []
    total_time = 0

    for epoch in range(num_epochs):
        start_time = time.time()
        running_loss = 0.0
        correct = 0
        total = 0

        pbar = tqdm(train_loader, desc=f'Epoch [{epoch + 1}/{num_epochs}]')
        for images, labels in pbar:
            images, labels = images.to(device), labels.to(device)

            outputs = model(images)
            loss = criterion(outputs, labels)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            running_loss += loss.item() * images.size(0)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

            pbar.set_postfix({'loss': loss.item(), 'acc': correct / total})

        epoch_loss = running_loss / total
        epoch_acc = correct / total
        train_losses.append(epoch_loss)
        train_accs.append(epoch_acc)
        epoch_time = time.time() - start_time
        total_time += epoch_time

        print(
            f'Epoch [{epoch + 1}/{num_epochs}] - Loss: {epoch_loss:.4f}, Acc: {epoch_acc:.4f}, Time: {epoch_time:.2f}s')

    print(f'\n训练完成！总训练时间: {total_time:.2f}s')
    return train_losses, train_accs


def test_model(model, test_loader, criterion, device):
    model.eval()
    test_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        pbar = tqdm(test_loader, desc='Testing')
        for images, labels in pbar:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)

            test_loss += loss.item() * images.size(0)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

            pbar.set_postfix({'loss': loss.item(), 'acc': correct / total})

    test_loss_avg = test_loss / total
    test_acc = correct / total
    print(f'\n测试集 - Loss: {test_loss_avg:.4f}, Accuracy: {test_acc:.4f}')
    return test_loss_avg, test_acc


# ===================== 5. 结果可视化 =====================
def plot_comparison(googlenet_losses, resnet_losses, googlenet_accs, resnet_accs, num_epochs):
    epochs = range(1, num_epochs + 1)
    plt.figure(figsize=(12, 4))

    plt.subplot(1, 2, 1)
    plt.plot(epochs, googlenet_losses, label='GoogleNet', marker='o')
    plt.plot(epochs, resnet_losses, label='ResNet', marker='s')
    plt.xlabel('Epoch')
    plt.ylabel('Training Loss')
    plt.title('Training Loss Comparison')
    plt.legend()
    plt.grid(True)

    plt.subplot(1, 2, 2)
    plt.plot(epochs, googlenet_accs, label='GoogleNet', marker='o')
    plt.plot(epochs, resnet_accs, label='ResNet', marker='s')
    plt.xlabel('Epoch')
    plt.ylabel('Training Accuracy')
    plt.title('Training Accuracy Comparison')
    plt.legend()
    plt.grid(True)

    plt.tight_layout()
    plt.savefig('model_comparison.png', dpi=300, bbox_inches='tight')
    plt.show()


# ===================== 6. 模型参数量计算 =====================
def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


# ===================== 主程序入口 =====================
if __name__ == '__main__':
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")

    learning_rate = 0.001
    num_epochs = 20
    num_classes = 10

    train_loader, test_loader = get_data_loaders()

    # 初始化模型
    googlenet = GoogleNet(num_classes=num_classes).to(device)
    resnet = ResNet(num_classes=num_classes).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer_googlenet = optim.Adam(googlenet.parameters(), lr=learning_rate)
    optimizer_resnet = optim.Adam(resnet.parameters(), lr=learning_rate)

    # 训练GoogleNet
    print("\n" + "=" * 50)
    print("开始训练GoogleNet")
    print("=" * 50)
    googlenet_train_losses, googlenet_train_accs = train_model(
        googlenet, train_loader, criterion, optimizer_googlenet, num_epochs, device
    )
    googlenet_test_loss, googlenet_test_acc = test_model(
        googlenet, test_loader, criterion, device
    )

    # 训练ResNet
    print("\n" + "=" * 50)
    print("开始训练ResNet")
    print("=" * 50)
    resnet_train_losses, resnet_train_accs = train_model(
        resnet, train_loader, criterion, optimizer_resnet, num_epochs, device
    )
    resnet_test_loss, resnet_test_acc = test_model(
        resnet, test_loader, criterion, device
    )

    # 可视化与对比
    plot_comparison(
        googlenet_train_losses, resnet_train_losses,
        googlenet_train_accs, resnet_train_accs,
        num_epochs
    )

    print("\n" + "=" * 50)
    print("模型最终性能对比")
    print("=" * 50)
    print(f"GoogleNet - 测试准确率: {googlenet_test_acc:.4f}, 测试损失: {googlenet_test_loss:.4f}")
    print(f"ResNet-18 - 测试准确率: {resnet_test_acc:.4f}, 测试损失: {resnet_test_loss:.4f}")
    print(f"\nGoogleNet参数量: {count_parameters(googlenet) / 1e6:.2f}M")
    print(f"ResNet-18参数量: {count_parameters(resnet) / 1e6:.2f}M")