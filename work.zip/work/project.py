import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from torch.utils.data import DataLoader, TensorDataset
from io import BytesIO, StringIO
from PIL import Image
from typing import Tuple, List, Dict, Any, Optional


def load_data(file_path: StringIO) -> Tuple[torch.Tensor, torch.Tensor]:
    """加载数据集并转换为Tensor格式"""
    data = pd.read_csv(file_path)
    x = torch.tensor(data['x'].values, dtype=torch.float32).reshape(-1, 1)
    y = torch.tensor(data['y'].values, dtype=torch.float32).reshape(-1, 1)
    return x, y


class LinearRegression(nn.Module):
    """线性回归模型"""

    def __init__(self) -> None:
        super(LinearRegression, self).__init__()
        self.linear = nn.Linear(1, 1)  # 输入特征数1，输出特征数1

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.linear(x)


def train_model(
        model: LinearRegression,
        optimizer: torch.optim.Optimizer,
        criterion: nn.MSELoss,
        train_loader: DataLoader,
        epochs: int,
        device: torch.device
) -> Tuple[List[float], List[float], List[float]]:
    """训练模型并返回损失和参数变化记录"""
    model.train()
    losses: List[float] = []
    weights: List[float] = []
    biases: List[float] = []

    for _ in range(epochs):
        epoch_loss = 0.0
        for x_batch, y_batch in train_loader:
            x_batch, y_batch = x_batch.to(device), y_batch.to(device)

            # 前向传播
            outputs = model(x_batch)
            loss = criterion(outputs, y_batch)

            # 反向传播和优化
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()

        avg_loss = epoch_loss / len(train_loader)
        losses.append(avg_loss)
        weights.append(model.linear.weight.item())
        biases.append(model.linear.bias.item())

    return losses, weights, biases


def fig_to_image(fig: plt.Figure) -> Image.Image:
    """将matplotlib图像转换为PIL Image"""
    buf = BytesIO()
    fig.savefig(buf, format='png', bbox_inches='tight')
    buf.seek(0)
    return Image.open(buf)


def plot_loss(losses_list: List[List[float]], labels: List[str]) -> Image.Image:
    """可视化不同优化器的损失曲线"""
    plt.figure(figsize=(10, 6))
    for losses, label in zip(losses_list, labels):
        plt.plot(losses, label=label)

    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Loss Curves for Different Optimizers')
    plt.legend()

    img = fig_to_image(plt.gcf())
    plt.close()
    return img


def plot_params(
        weights_list: List[List[float]],
        biases_list: List[List[float]],
        labels: List[str]
) -> Image.Image:
    """可视化不同优化器的参数变化"""
    fig, axes = plt.subplots(2, len(weights_list), figsize=(15, 8))

    for i, (weights, biases, label) in enumerate(zip(weights_list, biases_list, labels)):
        axes[0, i].plot(weights, label='Weight')
        axes[0, i].set_title(f'{label} - Weight')
        axes[0, i].set_xlabel('Epoch')
        axes[0, i].set_ylabel('Value')
        axes[0, i].legend()

        axes[1, i].plot(biases, label='Bias')
        axes[1, i].set_title(f'{label} - Bias')
        axes[1, i].set_xlabel('Epoch')
        axes[1, i].set_ylabel('Value')
        axes[1, i].legend()

    plt.tight_layout()
    img = fig_to_image(plt.gcf())
    plt.close()
    return img


def plot_lr_loss(losses_dict: Dict[float, List[float]]) -> Image.Image:
    """可视化不同学习率的损失曲线"""
    plt.figure(figsize=(10, 6))
    for lr, losses in losses_dict.items():
        plt.plot(losses, label=f'LR={lr}')

    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Loss Curves for Different Learning Rates')
    plt.legend()

    img = fig_to_image(plt.gcf())
    plt.close()
    return img


def plot_epoch_loss(losses_dict: Dict[int, List[float]]) -> Image.Image:
    """可视化不同迭代次数的损失曲线"""
    plt.figure(figsize=(10, 6))
    for epoch, losses in losses_dict.items():
        plt.plot(losses, label=f'Epochs={epoch}')

    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Loss Curves for Different Epoch Numbers')
    plt.legend()

    img = fig_to_image(plt.gcf())
    plt.close()
    return img


def create_sample_data() -> StringIO:
    """创建示例数据集"""
    data_str = "x,y\n"
    for i in range(100):
        x = i / 10.0
        y = 2.5 * x + 3.0 + np.random.normal(0, 0.5)
        data_str += f"{x},{y}\n"
    return StringIO(data_str)


def initialize_model(device: torch.device) -> LinearRegression:
    """初始化模型并设置随机参数"""
    model = LinearRegression().to(device)
    nn.init.normal_(model.linear.weight, mean=0, std=1)
    nn.init.normal_(model.linear.bias, mean=0, std=1)
    return model


def main() -> None:
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"使用设备: {device}")

    # 创建并加载数据
    file_path = create_sample_data()
    x, y = load_data(file_path)
    dataset = TensorDataset(x, y)
    train_loader = DataLoader(dataset, batch_size=16, shuffle=True)

    # 训练参数设置
    criterion = nn.MSELoss()
    epochs = 100

    # 比较不同优化器
    optimizers = {
        'SGD': torch.optim.SGD,
        'Adam': torch.optim.Adam,
        'Adagrad': torch.optim.Adagrad
    }

    losses_list: List[List[float]] = []
    weights_list: List[List[float]] = []
    biases_list: List[List[float]] = []
    labels: List[str] = []

    for name, optim_cls in optimizers.items():
        model = initialize_model(device)
        optimizer = optim_cls(model.parameters(), lr=0.01)
        losses, weights, biases = train_model(model, optimizer, criterion, train_loader, epochs, device)

        losses_list.append(losses)
        weights_list.append(weights)
        biases_list.append(biases)
        labels.append(name)

        print(f"{name}优化器训练完成，最终损失: {losses[-1]:.6f}")

    # 保存优化器比较可视化结果
    loss_img = plot_loss(losses_list, labels)
    loss_img.save('optimizer_losses.png')

    params_img = plot_params(weights_list, biases_list, labels)
    params_img.save('parameter_changes.png')

    # 学习率影响实验
    lrs = [0.001, 0.01, 0.1]
    lr_losses: Dict[float, List[float]] = {}

    for lr in lrs:
        model = initialize_model(device)
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
        losses, _, _ = train_model(model, optimizer, criterion, train_loader, epochs, device)
        lr_losses[lr] = losses
        print(f"学习率 {lr} 训练完成，最终损失: {losses[-1]:.6f}")

    lr_img = plot_lr_loss(lr_losses)
    lr_img.save('learning_rate_losses.png')

    # 迭代次数影响实验
    epochs_list = [50, 100, 200]
    epoch_losses: Dict[int, List[float]] = {}

    for epoch in epochs_list:
        model = initialize_model(device)
        optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
        losses, _, _ = train_model(model, optimizer, criterion, train_loader, epoch, device)
        epoch_losses[epoch] = losses
        print(f"迭代次数 {epoch} 训练完成，最终损失: {losses[-1]:.6f}")

    epoch_img = plot_epoch_loss(epoch_losses)
    epoch_img.save('epoch_losses.png')

    # 保存最佳模型
    best_model = initialize_model(device)
    best_optimizer = torch.optim.Adam(best_model.parameters(), lr=0.01)
    train_model(best_model, best_optimizer, criterion, train_loader, epochs, device)

    torch.save(best_model.state_dict(), 'best_linear_model.pth')
    print("训练性能最好的模型已保存为 best_linear_model.pth")
    print("所有可视化图像已保存为PNG文件")


if __name__ == '__main__':
    main()